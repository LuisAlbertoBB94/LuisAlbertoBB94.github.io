function interfaz_planta_general()
    clearvars -except interfaz_planta_general

    fig = uifigure('Name','Control PD/PID para sistemas inestables');
    fig.Position = [200 150 1050 580];

    % --- Título ---
    uilabel(fig, ...
        'Text', 'Control PD/PID para sistemas inestables con dos polos inestables y posibles pares de polos complejos conjugados', ...
        'FontSize', 17, ...
        'FontWeight', 'bold', ...
        'HorizontalAlignment', 'center', ...
        'Position', [10 530 1030 36]);

    % --- Panel izquierdo: Parámetros ---
    panel_izq = uipanel(fig,'Title','Parámetros del sistema','FontSize',13,...
        'Position',[20 110 380 400]);

    uilabel(panel_izq, 'Position', [20 320 170 22], 'Text', 'Polo real inestable a:');
    txt_a = uieditfield(panel_izq, 'numeric', 'Position', [200 320 80 22], 'Value', 0.2);

    uilabel(panel_izq, 'Position', [20 285 170 22], 'Text', 'Polo real inestable b:');
    txt_b = uieditfield(panel_izq, 'numeric', 'Position', [200 285 80 22], 'Value', 0.1);

    uilabel(panel_izq, 'Position', [20 250 170 22], 'Text', 'Ganancia (\beta):');
    txt_beta = uieditfield(panel_izq, 'numeric', 'Position', [200 250 80 22], 'Value', 1);

    uilabel(panel_izq, 'Position', [20 215 170 22], 'Text', 'Retardo (\tau):');
    txt_tau = uieditfield(panel_izq, 'numeric', 'Position', [200 215 80 22], 'Value', 0.25);

    uilabel(panel_izq, 'Position', [20 185 200 22], 'Text', 'Pares de polos complejos:');
    tbl = uitable(panel_izq, ...
        'Data', [2 5; 3 6], ...
        'ColumnName', {'Coef. lineal', 'Coef. cuadrático'}, ...
        'Position', [20 60 260 110], ...
        'ColumnEditable', [true true]);

    btn_add = uibutton(panel_izq, 'push', 'Text', 'Agregar Par', ...
        'Position', [290 130 80 30], ...
        'ButtonPushedFcn', @(btn,event) agregarPar(tbl));

    btn_del = uibutton(panel_izq, 'push', 'Text', 'Eliminar Par', ...
        'Position', [290 90 80 30], ...
        'ButtonPushedFcn', @(btn,event) eliminarPar(tbl));

    btn = uibutton(panel_izq, 'push', 'Text', 'Generar Planta', ...
        'Position', [110 20 160 35], ...
        'FontWeight','bold', ...
        'ButtonPushedFcn', @(btn,event) mostrarPlanta());

    % --- Panel derecho: Botones controladores ---
    panel_derA = uipanel(fig,'Title','Controladores','FontSize',13,...
        'Position',[430 330 590 180]);

    w = 220; h = 50; y_top = 100; gap = 10; x_left = 40;

    btn_PDmin = uibutton(panel_derA, 'push', 'Text', 'PD Fase Mínima', ...
        'Position', [x_left y_top w h], ...
        'FontSize',14, ...
        'ButtonPushedFcn', @(btn,event) abrir_con_espera(@()ventana_PD_min(txt_a.Value, txt_b.Value, txt_tau.Value, tbl.Data, txt_beta.Value), panel_derA));

    btn_PDno = uibutton(panel_derA, 'push', 'Text', 'PD Fase No Mínima', ...
        'Position', [x_left+w+gap y_top w h], ...
        'FontSize',14, ...
        'ButtonPushedFcn', @(btn,event) abrir_con_espera(@()ventana_PD_no_min(txt_a.Value, txt_b.Value, txt_tau.Value, tbl.Data, txt_beta.Value), panel_derA));

    btn_PIDno = uibutton(panel_derA, 'push', 'Text', 'PID Fase No Mínima', ...
        'Position', [x_left y_top-h-gap w h], ...
        'FontSize',14, ...
        'ButtonPushedFcn', @(btn,event) abrir_con_espera(@()ventana_PID_no_min(txt_a.Value, txt_b.Value, txt_tau.Value, tbl.Data, txt_beta.Value), panel_derA));

    % NUEVO BOTÓN: PID Fase Mínima
    btn_PIDmin = uibutton(panel_derA, 'push', 'Text', 'PID Fase Mínima', ...
        'Position', [x_left+w+gap y_top-h-gap w h], ...
        'FontSize',14, ...
        'ButtonPushedFcn', @(btn,event) abrir_con_espera(@()ventana_PID_min(txt_a.Value, txt_b.Value, txt_tau.Value, tbl.Data, txt_beta.Value), panel_derA));

    % --- Panel de función de transferencia ---
    panel_derB = uipanel(fig,'Title','Función de transferencia','FontSize',13,...
        'Position',[430 110 590 200]);

    txt_planta = uitextarea(panel_derB, ...
        'Position', [25 35 540 140], ...
        'FontName', 'Consolas', ...
        'FontSize', 15, ...
        'Editable', 'off', ...
        'HorizontalAlignment','center', ...
        'Value', {''; 'La función de transferencia aparecerá aquí.'; ''});

    % --- Funciones internas ---
    function agregarPar(tbl)
        datos = tbl.Data;
        datos = [datos; 0 0];
        tbl.Data = datos;
    end

    function eliminarPar(tbl)
        datos = tbl.Data;
        if size(datos,1) > 1
            datos(end,:) = [];
        end
        tbl.Data = datos;
    end

    function mostrarPlanta()
        a = txt_a.Value;
        b = txt_b.Value;
        beta = txt_beta.Value;
        tau = txt_tau.Value;
        polos_cplx = tbl.Data;

        if any(isnan(polos_cplx(:)))
            uialert(fig, 'Por favor, llena todos los coeficientes de los pares de polos complejos.', 'Error de entrada');
            return;
        end

        num_str = num2str(beta);
        den_factors = {['(s-' num2str(a) ')'], ['(s-' num2str(b) ')']};

        for i=1:size(polos_cplx,1)
            coef1 = polos_cplx(i,1);
            coef2 = polos_cplx(i,2);
            den_factors{end+1} = ['(s^2+' num2str(coef1) 's+' num2str(coef2) ')'];
        end

        den_str = strjoin(den_factors, '');
        if tau > 0
            exp_str = ['exp(-' num2str(tau) 's) * '];
        else
            exp_str = '';
        end

        linea1 = ['           ' exp_str num_str];
        linea2 = 'G(s) =  ----------------------------------------';
        linea3 = ['          ' den_str];
        txt_planta.Value = {linea1; linea2; linea3};
    end

    function abrir_con_espera(f_handle, panel)
        reloj = uilabel(panel, 'Text','⏳','FontSize',40,'Position',[400 40 50 60],'HorizontalAlignment','center');
        drawnow;
        try
            f_handle();
        catch ME
            delete(reloj);
            rethrow(ME)
        end
        pause(0.5);
        delete(reloj);
    end
end
