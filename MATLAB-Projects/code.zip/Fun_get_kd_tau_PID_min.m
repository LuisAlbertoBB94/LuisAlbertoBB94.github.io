function resultados_PID = Fun_get_kd_tau_PID_min(a, b, omega_n, zeta, tau_max, omega_max, tolerancia, k_i)
% Genera combinaciones válidas (k_d, tau) para un PID de fase mínima
% usando la ecuación de fase de Q4(s).
    n_pts_kd = 100;    % Resolución en k_d
    n_pts_tau = 100;   % Resolución en tau
    kd_min = 0.01;
    kd_max = 100;
    tau_min = 0.001;

    k_d_vec = linspace(kd_min, kd_max, n_pts_kd);
    tau_vec = linspace(tau_min, tau_max, n_pts_tau);
    N = length(omega_n);

    resultados_PID = [];

    for ik = 1:length(k_d_vec)
        for jt = 1:length(tau_vec)
            k_d = k_d_vec(ik);
            tau = tau_vec(jt);

            omega = linspace(0.01, omega_max, 1000); % Evita w=0
            fase = zeros(size(omega));
            for iw = 1:length(omega)
                w = omega(iw);
                fase_sum = atan2(w, a) + atan2(w, b) - w*tau - 2*pi ...
                         + atan2(k_d*w - k_i/w, 1);
                for m = 1:N
                    num = 2*zeta(m)*omega_n(m)*w;
                    den = omega_n(m)^2 - w^2;
                    fase_sum = fase_sum - atan2(num, den);
                end
                fase(iw) = fase_sum;
            end
            % Buscar cruces por -pi detectando cambios de signo cerca de -pi
            cruces = find(diff(sign(fase + pi)) ~= 0);
            % O aceptar si algún valor está suficientemente cerca de -pi
            if ~isempty(cruces) || any(abs(fase + pi) < tolerancia)
                resultados_PID = [resultados_PID; k_d, tau];
            end
        end
    end
end
