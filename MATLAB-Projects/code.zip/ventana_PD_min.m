function ventana_PD_min(a, b, tau_in, polos_cplx, beta)
    N = size(polos_cplx,1);
    omega_n = sqrt(polos_cplx(:,2))';
    zeta = polos_cplx(:,1)' ./ (2*omega_n);
    suma_zeta_omega = sum(2*zeta./omega_n);
    suma_cuadrados = sum((4*zeta-2)./(omega_n.^2));
    tau_max = 1/a + 1/b - suma_zeta_omega - sqrt(1/a^2 + 1/b^2 + suma_cuadrados);

    omega_max = 3;
    tolerancia = 0.01;

    ventana = uifigure('Name','Sintonización PD Fase Mínima');
    ventana.Position = [100 100 1250 700];

    % --------- CUADRANTE 1: Izquierda-Arriba (título + área) ----------
    panelA = uipanel(ventana,'Position',[20 370 400 320]);
    uilabel(panelA, 'Text', 'Sintonización PD Fase Mínima', ...
        'Position', [10 270 380 30], 'FontSize', 18, 'FontWeight','bold','HorizontalAlignment','left');
    uilabel(panelA, 'Text', [char(964) '_{max} = ' num2str(tau_max, '%.4f')], ...
        'Position', [10 240 250 22], 'FontSize', 13, 'FontWeight','bold','HorizontalAlignment','left');
    resultados = Fun_get_kd_tau_N(a, b, omega_n, zeta, tau_max, omega_max, tolerancia);
    ax_area = uiaxes(panelA, 'Position', [10 10 370 220], 'FontSize',12);
    hold(ax_area,'on')
    x_resultados = resultados(:, 1);
    y_resultados = resultados(:, 2);
    k = boundary(x_resultados, y_resultados);
    fill(ax_area, x_resultados(k), y_resultados(k), [0.9 0.9 0.9], 'EdgeColor', 'none', 'HitTest','off');
    pltpts = plot(ax_area, x_resultados, y_resultados, '.', 'Color', [0.5 0.5 0.5], 'MarkerSize', 7);
    plot(ax_area, x_resultados(k), y_resultados(k), 'k-', 'LineWidth', 1.5, 'HitTest','off');
    xlabel(ax_area, 'k_d'); ylabel(ax_area, '\tau');
    title(ax_area, 'Área de combinaciones estabilizantes');
    grid(ax_area, 'on');
    axis(ax_area, [min(x_resultados)-1 max(x_resultados)+1 min(y_resultados) max(y_resultados)+.03]);
    hold(ax_area,'off')
    set(ax_area,'ButtonDownFcn',@clic_en_area)
    pltpts.ButtonDownFcn = @clic_en_punto;

    % --------- CUADRANTE 2: Izquierda-Abajo (2 filas: botones/consola) ----------
    panelB = uipanel(ventana,'Position',[20 20 400 330],'Title','Controles y Resultados');
    % Fila superior (botones)
    panelBotones = uipanel(panelB, 'Position', [5 170 390 140],'BorderType','none');
    btn_omega = uibutton(panelBotones, 'Text', sprintf('Modificar \\omega_{max} (%.2f)', omega_max), ...
        'Position', [30 70 160 40], 'FontWeight','bold', 'FontSize',13, ...
        'ButtonPushedFcn', @(src,event) cambiar_omega());
    btn_tol = uibutton(panelBotones, 'Text', sprintf('Modificar tolerancia (%.3f)', tolerancia), ...
        'Position', [200 70 160 40], 'FontWeight','bold', 'FontSize',13, ...
        'ButtonPushedFcn', @(src,event) cambiar_tol());
    % Fila inferior (consola/salida)
    txt_result = uitextarea(panelB, ...
        'Position', [10 10 380 150], ...
        'FontName', 'Consolas', ...
        'FontSize', 13, ...
        'Editable', 'off', ...
        'Value', {'Selecciona un punto (k_d, \tau) en el área estabilizante.'});

    % --------- CUADRANTE 3: Derecha-Arriba (Gráfica de fase) ----------
    panelC = uipanel(ventana,'Position',[440 370 780 320]);
    ax_fase = uiaxes(panelC, 'Position', [40 40 700 240], 'FontSize',14);
    title(ax_fase, '\Phi_{Q_3}(\omega)','FontWeight','bold','FontSize',16);
    xlabel(ax_fase, '\omega','FontSize',14);
    ylabel(ax_fase, '\Phi_{Q_3}(\omega)','FontSize',14);
    grid(ax_fase, 'on');
    % Leyenda explicativa debajo del eje de fase
    uilabel(panelC, ...
    'Text', sprintf(['En el diagrama de fase deben observarse dos cruces por -\\pi (curva característica esperada).\n', ...
    'Si aparece algún pico, discontinuidad o más/menos cruces, ajusta el valor de \\omega_{max}.']), ...
    'FontSize', 12, ...
    'FontAngle', 'italic', ...
    'Position', [20 5 740 38], ... % ¡Aumenta ancho y alto!
    'HorizontalAlignment','center', ...
    'FontColor', [0.6 0.1 0.1]);


    % --------- CUADRANTE 4: Derecha-Abajo (Sintonizar PD) ----------
    panelD = uipanel(ventana,'Position',[440 20 780 330]);

    % ---- Variables compartidas para Kp/Nyquist ----
    selected_params = struct('k_d', [], 'tau', [], 'omega_c1', [], 'omega_cg', [], 'kp_min', [], 'kp_max', [], 'kp_sel', []);

    % --------- CALLBACKS ----------
    ax_area.ButtonDownFcn = @clic_en_area;
    pltpts.ButtonDownFcn = @clic_en_punto;

    function clic_en_area(~, event)
        pt = ax_area.CurrentPoint;
        selected_kd = pt(1,1);
        selected_tau = pt(1,2);
        [wc1, wcg] = obtener_omegas(selected_kd, selected_tau);
        actualizarFase(selected_kd, selected_tau, wc1, wcg)
    end

    function clic_en_punto(src,event)
        pt = ax_area.CurrentPoint;
        selected_kd = pt(1,1);
        selected_tau = pt(1,2);
        [wc1, wcg] = obtener_omegas(selected_kd, selected_tau);
        actualizarFase(selected_kd, selected_tau, wc1, wcg)
    end

    function actualizarFase(selected_kd, selected_tau, wc1, wcg)
        txt_result.Value = {
            sprintf('Seleccionado: k_d = %.4f, \\tau = %.4f', selected_kd, selected_tau), ...
            sprintf('\\omega_{c1} = %.4f', wc1), ...
            sprintf('\\omega_{cg} = %.4f', wcg), ...
            '--------------------------------------------------', ...
            'Haz clic en otro punto para actualizar.'};
        % Resalta el punto
        cla(ax_area);
        hold(ax_area,'on')
        fill(ax_area, x_resultados(k), y_resultados(k), [0.9 0.9 0.9], 'EdgeColor', 'none', 'HitTest','off');
        plot(ax_area, x_resultados, y_resultados, '.', 'Color', [0.5 0.5 0.5], 'MarkerSize', 7, 'ButtonDownFcn', @clic_en_punto);
        plot(ax_area, x_resultados(k), y_resultados(k), 'k-', 'LineWidth', 1.5, 'HitTest','off');
        plot(ax_area, selected_kd, selected_tau, 'ro', 'MarkerSize', 12, 'LineWidth', 2);
        xlabel(ax_area, 'k_d'); ylabel(ax_area, '\tau');
        title(ax_area, 'Área de combinaciones estabilizantes');
        grid(ax_area, 'on');
        axis(ax_area, [min(x_resultados)-1 max(x_resultados)+1 min(y_resultados) max(y_resultados)+.03]);
        hold(ax_area,'off')
        % Graficar fase
        omega = linspace(0, omega_max, 1000);
        funcion = zeros(size(omega));
        for i = 1:length(omega)
            w = omega(i);
            phase_sum = atan2(w * selected_kd, 1) + ...
            atan2(w, a) + ...
            atan2(w, b) - ...
            w * selected_tau;
            for m = 1:N
                num = 2 * omega_n(m) * zeta(m) * w;
                den = omega_n(m)^2 - w^2;
                phase_sum = phase_sum - atan2(num, den);
            end           
            phase_sum = phase_sum - 2*pi;
            funcion(i) = phase_sum;
        end
        cla(ax_fase);
        plot(ax_fase, omega, funcion, 'b', 'LineWidth', 1.7);
        hold(ax_fase, 'on');
        plot(ax_fase, [0, omega_max], [-pi, -pi], 'k--', 'LineWidth', 1.2);
        hold(ax_fase, 'off');
        ax_fase.YLim = [-3.5 -2.8];
        ax_fase.XLim = [0 omega_max];
        legend(ax_fase, '\Phi_{Q_3}(\omega)', '-\pi','Location','southwest')
        % Guarda los parámetros para sintonía en variable compartida
        selected_params.k_d = selected_kd;
        selected_params.tau = selected_tau;
        selected_params.omega_c1 = wc1;
        selected_params.omega_cg = wcg;
        selected_params.kp_sel = NaN;
        % Limpia panel de sintonía (panelD) cada que se selecciona nuevo punto
        delete(panelD.Children)
        btn_pd = uibutton(panelD, 'push', 'Text', 'Sintonizar Parámetros Estabilizantes', ...
            'Position', [50 250 350 60], 'FontWeight','bold', ...
            'FontSize',15, ...
            'ButtonPushedFcn', @(btn,event) sintonizar_pd());
    end

function [wc1, wcg] = obtener_omegas(kd, tau)
    omega = linspace(0, omega_max, 1000);
    funcion = zeros(size(omega));
    
    for i = 1:length(omega)
        w = omega(i);
        phase_sum = atan2(w * kd, 1) + ...
                    atan2(w, a) + ...
                    atan2(w, b) - ...
                    w * tau;
        for m = 1:N
            num = 2 * omega_n(m) * zeta(m) * w;
            den = omega_n(m)^2 - w^2;
            phase_sum = phase_sum - atan2(num, den);
        end
        phase_sum = phase_sum - 2*pi;  % Ajuste típico para sistemas con 2 polos RHP
        funcion(i) = phase_sum;
    end

    idx = find(abs(funcion + pi) < tolerancia);  % cruces por -pi

    if isempty(idx)
        wc1 = NaN;
        wcg = NaN;
    elseif length(idx) == 1
        wc1 = omega(idx(1));
        wcg = NaN;
    else
        wc1 = omega(idx(1));
        wcg = omega(idx(end));
    end
end


    function cambiar_omega()
        resp = inputdlg({'Nuevo valor de \omega_{max}:'}, 'Modificar \omega_{max}', [1 35], {num2str(omega_max)});
        if ~isempty(resp)
            val = str2double(resp{1});
            if isnumeric(val) && val > 0
                hWait = uilabel(panelB,'Position',[170 120 60 40],'FontSize',35,'Text','⏳');
                drawnow;
                try
                    omega_max = val;
                    btn_omega.Text = sprintf('Modificar \\omega_{max} (%.2f)', omega_max);
                    resultados = Fun_get_kd_tau_N(a, b, omega_n, zeta, tau_max, omega_max, tolerancia);
                    x_resultados = resultados(:, 1);
                    y_resultados = resultados(:, 2);
                    k = boundary(x_resultados, y_resultados);
                    cla(ax_area);
                    fill(ax_area, x_resultados(k), y_resultados(k), [0.9 0.9 0.9], 'EdgeColor', 'none', 'HitTest','off');
                    pltpts = plot(ax_area, x_resultados, y_resultados, '.', 'Color', [0.5 0.5 0.5], 'MarkerSize', 7);
                    plot(ax_area, x_resultados(k), y_resultados(k), 'k-', 'LineWidth', 1.5, 'HitTest','off');
                    xlabel(ax_area, 'k_d'); ylabel(ax_area, '\tau');
                    title(ax_area, 'Área de combinaciones estabilizantes');
                    grid(ax_area, 'on');
                    axis(ax_area, [min(x_resultados)-1 max(x_resultados)+1 min(y_resultados) max(y_resultados)+.03]);
                    pltpts.ButtonDownFcn = @clic_en_punto; 
                catch
                end
                delete(hWait);
            end
        end
    end

    function cambiar_tol()
        resp = inputdlg({'Nuevo valor de tolerancia:'}, 'Modificar tolerancia', [1 35], {num2str(tolerancia)});
        if ~isempty(resp)
            val = str2double(resp{1});
            if isnumeric(val) && val > 0
                hWait = uilabel(panelB,'Position',[170 120 60 40],'FontSize',35,'Text','⏳');
                drawnow;
                try
                    tolerancia = val;
                    btn_tol.Text = sprintf('Modificar tolerancia (%.3f)', tolerancia);
                    resultados = Fun_get_kd_tau_N(a, b, omega_n, zeta, tau_max, omega_max, tolerancia);
                    x_resultados = resultados(:, 1);
                    y_resultados = resultados(:, 2);
                    k = boundary(x_resultados, y_resultados);
                    cla(ax_area);
                    fill(ax_area, x_resultados(k), y_resultados(k), [0.9 0.9 0.9], 'EdgeColor', 'none', 'HitTest','off');
                    pltpts = plot(ax_area, x_resultados, y_resultados, '.', 'Color', [0.5 0.5 0.5], 'MarkerSize', 7);
                    plot(ax_area, x_resultados(k), y_resultados(k), 'k-', 'LineWidth', 1.5, 'HitTest','off');
                    xlabel(ax_area, 'k_d'); ylabel(ax_area, '\tau');
                    title(ax_area, 'Área de combinaciones estabilizantes');
                    grid(ax_area, 'on');
                    axis(ax_area, [min(x_resultados)-1 max(x_resultados)+1 min(y_resultados) max(y_resultados)+.03]);
                    pltpts.ButtonDownFcn = @clic_en_punto; 
                catch
                end
                delete(hWait);
            end
        end
    end

    function sintonizar_pd()
    delete(panelD.Children);

    a_val = a;
    b_val = b;
    k_d = selected_params.k_d;
    omega_c1 = selected_params.omega_c1;
    omega_cg = selected_params.omega_cg;

    if isnan(omega_c1) || isnan(omega_cg)
        uilabel(panelD, 'Text', 'Selecciona (k_d, \tau) válidos para calcular el intervalo de k_p.', ...
            'Position', [40 220 670 50], 'FontSize', 15, 'FontColor', [0.8 0.2 0.2]);
        return;
    end

    prod_min = 1; prod_max = 1;
    for m = 1:N
        prod_min = prod_min * sqrt(omega_c1^4 + 2*omega_n(m)^2*(2*zeta(m)^2 - 1)*omega_c1^2 + omega_n(m)^4);
        prod_max = prod_max * sqrt(omega_cg^4 + 2*omega_n(m)^2*(2*zeta(m)^2 - 1)*omega_cg^2 + omega_n(m)^4);
    end

    kp_min = (1/beta) * (sqrt(omega_c1^2 + a_val^2) * sqrt(omega_c1^2 + b_val^2) * prod_min) / sqrt(k_d^2 * omega_c1^2 + 1);
    kp_max = (1/beta) * (sqrt(omega_cg^2 + a_val^2) * sqrt(omega_cg^2 + b_val^2) * prod_max) / sqrt(k_d^2 * omega_cg^2 + 1);
    kp_pdMin = (kp_min + kp_max)/2;

    selected_params.kp_min = kp_min;
    selected_params.kp_max = kp_max;
    selected_params.kp_sel = kp_pdMin;

    % ---- Divide el cuadrante 4 en dos paneles ----
    anchoIzq = 350; anchoDer = 410;
    alto = 290;
    offy = 25;

    panelD_izq = uipanel(panelD, 'Position', [15 offy anchoIzq alto], 'BorderType','none');
    panelD_der = uipanel(panelD, 'Position', [anchoIzq+40 offy anchoDer alto], 'BorderType','none');

    % Panel IZQUIERDO: textos, controles, botón
   % Intervalo de kp
uilabel(panelD_izq, ...
    'Text', sprintf('Intervalo estabilizante de k_p:\n[%.4f , %.4f]', kp_min, kp_max), ...
    'Position', [10 190 330 40], 'FontSize', 15, 'FontWeight', 'bold');

% Sugerido
uilabel(panelD_izq, ...
    'Text', sprintf('Valor sugerido (promedio):\nk_p = %.4f', kp_pdMin), ...
    'Position', [10 145 330 35], 'FontSize', 13);

% Etiqueta para seleccionar kp
uilabel(panelD_izq, ...
    'Text', 'Selecciona un valor de k_p dentro del intervalo:', ...
    'Position', [10 110 250 30], 'FontSize', 13);

% Campo de kp (debajo de la etiqueta)
edt_kp = uieditfield(panelD_izq, 'numeric', ...
    'Position', [10 80 90 28], ...
    'Value', kp_pdMin, 'Limits', [kp_min kp_max], 'RoundFractionalValues','off');

% Botón Nyquist (a la derecha del campo kp, no encimado)
btn_nyq = uibutton(panelD_izq, 'push', 'Text', 'Graficar Nyquist', ...
    'Position', [110 80 180 32], 'FontWeight','bold', 'FontSize',14, ...
    'ButtonPushedFcn', @(src,event) graficar_nyquist());


    % Panel DERECHO: axes Nyquist
    ax_nyq = uiaxes(panelD_der, 'Position', [10 5 390 250], 'FontSize',13, 'Box','on');
    title(ax_nyq, 'Diagrama de Nyquist');

    % Función interna para Nyquist
   function graficar_nyquist()
    kp_val = edt_kp.Value;
    selected_params.kp_sel = kp_val;

    % Definir sistema
    s = tf('s');
    G_uns = zpk([], [a_val b_val], beta, 'outputdelay', tau_in);
    G_total = G_uns;
    for m = 1:N
        G_par = tf([1], [1 polos_cplx(m,1) polos_cplx(m,2)]);
        G_total = G_total * G_par;
    end

    PD = pid(1, 0, k_d);
    Gt = G_total * PD * kp_val;

    % Nyquist con mayor resolución
    w = [0, logspace(-2, 2, 5000)];
    [re, im] = nyquist(Gt, w);
    re = squeeze(re);
    im = squeeze(im);

    % Graficar en formato deseado
    cla(ax_nyq);
    plot(ax_nyq, re, im, 'b', 'LineWidth', 1.5); hold(ax_nyq, 'on');
    plot(ax_nyq, re, -im, 'b--', 'LineWidth', 1);  % Simetría inferior
    plot(ax_nyq, -1, 0, 'rx', 'MarkerSize', 10, 'LineWidth', 2); % Punto crítico
    xlabel(ax_nyq, 'Re'); ylabel(ax_nyq, 'Im');
    axis(ax_nyq, 'equal');
    grid(ax_nyq, 'on');
    title(ax_nyq, 'Diagrama de Nyquist');
end

end
end
