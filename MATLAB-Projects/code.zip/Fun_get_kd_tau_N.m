function resultados_PID = Fun_get_kd_tau_N(a, b, omega_n, zeta, tau_max, omega_max, tolerancia)
    % Vector de k_d y tau (ajusta la resolución según necesidades)
    k_d_values = linspace(0, 200, 120);    % k_d de 0 a 200
    tau_values = linspace(0, tau_max, 180); % tau de 0 a tau_max
    omega = linspace(0, omega_max, 120);   % omega de 0 a omega_max

    resultados_PID = [];
    N = length(omega_n);

    for i = 1:length(k_d_values)
        for j = 1:length(tau_values)
            k_d = k_d_values(i);
            tau = tau_values(j);
            % Calcula la fase en cada omega
            funcion = atan2(omega * k_d, 1) + atan2(omega, a) + atan2(omega, b) - omega * tau;
            for m = 1:N
                num = 2 * omega_n(m) * zeta(m) .* omega;
                den = omega_n(m)^2 - omega.^2;
                funcion = funcion - atan2(num, den); % <<--- CORREGIDO
            end            
            funcion = funcion - 2*pi;
            % ¿Hay algún omega donde la condición se cumple?
            if any(funcion > -pi + tolerancia) % Usando tolerancia
                resultados_PID = [resultados_PID; k_d, tau];
            end
        end
    end
end
