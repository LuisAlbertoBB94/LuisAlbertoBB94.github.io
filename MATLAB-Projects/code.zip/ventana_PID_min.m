function ventana_PID_min(a, b, tau_in, polos_cplx, beta)
    % Parámetros generales
    N = size(polos_cplx,1);
    omega_n = sqrt(polos_cplx(:,2))';
    zeta = polos_cplx(:,1)' ./ (2*omega_n);
    suma_zeta_omega = sum(2*zeta./omega_n);
    suma_cuadrados = sum((4*zeta-2)./(omega_n.^2));
    tau_max = 1/a + 1/b - suma_zeta_omega - sqrt(1/a^2 + 1/b^2 + suma_cuadrados);

    omega_max = 3;
    tolerancia = 0.01;
    k_i = 0.01;

    ventana = uifigure('Name','Sintonización PID Fase Mínima');
    ventana.Position = [100 100 1250 700];

    % Panel Área (Arriba Izquierda)
    panelA = uipanel(ventana,'Position',[20 370 400 320]);
    uilabel(panelA, 'Text', 'Sintonización PID Fase Mínima', ...
        'Position', [10 270 380 30], 'FontSize', 18, 'FontWeight','bold','HorizontalAlignment','left');
    uilabel(panelA, 'Text', [char(964) '_{max} = ' num2str(tau_max, '%.4f')], ...
        'Position', [10 240 250 22], 'FontSize', 13, 'FontWeight','bold','HorizontalAlignment','left');
    resultados = Fun_get_kd_tau_PID_min(a, b, omega_n, zeta, tau_max, omega_max, tolerancia, k_i);
    ax_area = uiaxes(panelA, 'Position', [10 10 370 220], 'FontSize',12);
    hold(ax_area,'on')
    x_resultados = resultados(:, 1);
    y_resultados = resultados(:, 2);
    k = boundary(x_resultados, y_resultados);
    fill(ax_area, x_resultados(k), y_resultados(k), [0.9 0.9 0.9], 'EdgeColor', 'none', 'HitTest','off');
    pltpts = plot(ax_area, x_resultados, y_resultados, '.', 'Color', [0.5 0.5 0.5], 'MarkerSize', 7);
    plot(ax_area, x_resultados(k), y_resultados(k), 'k-', 'LineWidth', 1.5, 'HitTest','off');
    xlabel(ax_area, 'k_d'); ylabel(ax_area, '\tau');
    title(ax_area, 'Área de combinaciones estabilizantes');
    grid(ax_area, 'on');
    axis(ax_area, [min(x_resultados)-1 max(x_resultados)+1 min(y_resultados) max(y_resultados)+.03]);
    hold(ax_area,'off')
    set(ax_area,'ButtonDownFcn',@clic_en_area)
    pltpts.ButtonDownFcn = @clic_en_punto;

    % Panel Controles (Abajo Izquierda)
    panelB = uipanel(ventana,'Position',[20 20 400 330],'Title','Controles y Resultados');
    panelBotones = uipanel(panelB, 'Position', [5 170 390 140],'BorderType','none');
    btn_omega = uibutton(panelBotones, 'Text', sprintf('Modificar \\omega_{max} (%.2f)', omega_max), ...
        'Position', [20 80 160 40], 'FontWeight','bold', 'FontSize',13, ...
        'ButtonPushedFcn', @(src,event) cambiar_omega());
    btn_tol = uibutton(panelBotones, 'Text', sprintf('Modificar tolerancia (%.3f)', tolerancia), ...
        'Position', [200 80 160 40], 'FontWeight','bold', 'FontSize',13, ...
        'ButtonPushedFcn', @(src,event) cambiar_tol());
    btn_ki = uibutton(panelBotones, 'Text', sprintf('Modificar k_i (%.3f)', k_i), ...
        'Position', [110 20 170 40], 'FontWeight','bold', 'FontSize',13, ...
        'ButtonPushedFcn', @(src,event) cambiar_ki());
    txt_result = uitextarea(panelB, ...
        'Position', [10 10 380 150], ...
        'FontName', 'Consolas', ...
        'FontSize', 13, ...
        'Editable', 'off', ...
        'Value', {'Selecciona un punto (k_d, \tau) en el área estabilizante.'});

    % Panel Fase (Arriba Derecha)
    panelC = uipanel(ventana,'Position',[440 370 780 320]);
    ax_fase = uiaxes(panelC, 'Position', [40 40 700 240], 'FontSize',14);
    title(ax_fase, '\Phi_{Q_4}(\omega)','FontWeight','bold','FontSize',16);
    xlabel(ax_fase, '\omega','FontSize',14);
    ylabel(ax_fase, '\Phi_{Q_4}(\omega)','FontSize',14);
    grid(ax_fase, 'on');
    uilabel(panelC, ...
    'Text', sprintf(['En el diagrama de fase deben observarse tres cruces por -\\pi (ignora el primero, solo usa los últimos dos).\n', ...
    'Si aparece algún pico, discontinuidad o más/menos cruces, ajusta el valor de \\omega_{max} o k_i.']), ...
    'FontSize', 12, ...
    'FontAngle', 'italic', ...
    'Position', [20 5 740 38], ...
    'HorizontalAlignment','center', ...
    'FontColor', [0.6 0.1 0.1]);

    % Panel Sintonía y Nyquist (Abajo Derecha)
    panelD = uipanel(ventana,'Position',[440 20 780 330]);

    selected_params = struct('k_d', [], 'tau', [], 'omega_c1', [], 'omega_c2', [], 'kp_min', [], 'kp_max', [], 'kp_sel', []);

    % Callbacks
    ax_area.ButtonDownFcn = @clic_en_area;
    pltpts.ButtonDownFcn = @clic_en_punto;

    function clic_en_area(~, event)
        pt = ax_area.CurrentPoint;
        selected_kd = pt(1,1);
        selected_tau = pt(1,2);
        [wc1, wc2] = obtener_omegas(selected_kd, selected_tau, k_i);
        actualizarFase(selected_kd, selected_tau, wc1, wc2)
    end

    function clic_en_punto(~,~)
        pt = ax_area.CurrentPoint;
        selected_kd = pt(1,1);
        selected_tau = pt(1,2);
        [wc1, wc2] = obtener_omegas(selected_kd, selected_tau, k_i);
        actualizarFase(selected_kd, selected_tau, wc1, wc2)
    end

    function actualizarFase(selected_kd, selected_tau, wc1, wc2)
        txt_result.Value = {
            sprintf('Seleccionado: k_d = %.4f, \\tau = %.4f', selected_kd, selected_tau), ...
            sprintf('\\omega_{c1} = %.4f', wc1), ...
            sprintf('\\omega_{c2} = %.4f', wc2), ...
            '--------------------------------------------------', ...
            'Haz clic en otro punto para actualizar.'};
        % Resalta el punto
        cla(ax_area);
        hold(ax_area,'on')
        fill(ax_area, x_resultados(k), y_resultados(k), [0.9 0.9 0.9], 'EdgeColor', 'none', 'HitTest','off');
        plot(ax_area, x_resultados, y_resultados, '.', 'Color', [0.5 0.5 0.5], 'MarkerSize', 7, 'ButtonDownFcn', @clic_en_punto);
        plot(ax_area, x_resultados(k), y_resultados(k), 'k-', 'LineWidth', 1.5, 'HitTest','off');
        plot(ax_area, selected_kd, selected_tau, 'ro', 'MarkerSize', 12, 'LineWidth', 2);
        xlabel(ax_area, 'k_d'); ylabel(ax_area, '\tau');
        title(ax_area, 'Área de combinaciones estabilizantes');
        grid(ax_area, 'on');
        axis(ax_area, [min(x_resultados)-1 max(x_resultados)+1 min(y_resultados) max(y_resultados)+.03]);
        hold(ax_area,'off')
        % Graficar fase
        omega = linspace(0.01, omega_max, 4000);
        phi = zeros(size(omega));
        for i = 1:length(omega)
            w = omega(i);
            if w == 0
                argPID = 0;
            else
                argPID = atan2(selected_kd*w - k_i/w, 1);
            end
            suma = atan2(w, a) + atan2(w, b) - w*selected_tau - 2*pi + argPID;
            for m = 1:N
                num = 2 * omega_n(m) * zeta(m) * w;
                den = omega_n(m)^2 - w^2;
                suma = suma - atan2(num, den);
            end
            phi(i) = suma;
        end

        cruces = find(diff(sign(phi + pi)) ~= 0);
        if numel(cruces) < 3
            wc1 = NaN; wc2 = NaN;
            txt_result.Value = {'No se detectaron tres cruces por -\pi. Ajusta parámetros.'};
            return;
        end
        omega_c1 = omega(cruces(2));
        omega_c2 = omega(cruces(3));

        cla(ax_fase);
        plot(ax_fase, omega, phi, 'b', 'LineWidth', 1.7);
        hold(ax_fase, 'on');
        yline(ax_fase, -pi, '--k', 'LineWidth', 1.2);
        hold(ax_fase, 'off');
        ax_fase.YLim = [-4 -2.7];
        ax_fase.XLim = [0 omega_max];
        legend(ax_fase, '\Phi_{Q_4}(\omega)', '-\pi','Location','southwest')

        selected_params.k_d = selected_kd;
        selected_params.tau = selected_tau;
        selected_params.omega_c1 = omega_c1;
        selected_params.omega_c2 = omega_c2;
        selected_params.kp_sel = NaN;
        delete(panelD.Children)
        btn_pid = uibutton(panelD, 'push', 'Text', 'Sintonizar Parámetros Estabilizantes', ...
            'Position', [50 250 350 60], 'FontWeight','bold', ...
            'FontSize',15, ...
            'ButtonPushedFcn', @(btn,event) sintonizar_pid());
    end

    function [wc1, wc2] = obtener_omegas(kd, tau, ki)
        omega = linspace(0.01, omega_max, 4000);
        phi = zeros(size(omega));
        for i = 1:length(omega)
            w = omega(i);
            if w == 0
                argPID = 0;
            else
                argPID = atan2(kd*w - ki/w, 1);
            end
            suma = atan2(w, a) + atan2(w, b) - w*tau - 2*pi + argPID;
            for m = 1:N
                num = 2 * omega_n(m) * zeta(m) * w;
                den = omega_n(m)^2 - w^2;
                suma = suma - atan2(num, den);
            end
            phi(i) = suma;
        end
        cruces = find(diff(sign(phi + pi)) ~= 0);
        if numel(cruces) < 3
            wc1 = NaN; wc2 = NaN;
        else
            wc1 = omega(cruces(2));
            wc2 = omega(cruces(3));
        end
    end

    function cambiar_omega()
        resp = inputdlg({'Nuevo valor de \omega_{max}:'}, 'Modificar \omega_{max}', [1 35], {num2str(omega_max)});
        if ~isempty(resp)
            val = str2double(resp{1});
            if isnumeric(val) && val > 0
                hWait = uilabel(panelB,'Position',[170 120 60 40],'FontSize',35,'Text','⏳');
                drawnow;
                try
                    omega_max = val;
                    btn_omega.Text = sprintf('Modificar \\omega_{max} (%.2f)', omega_max);
                    resultados = Fun_get_kd_tau_PID_min(a, b, omega_n, zeta, tau_max, omega_max, tolerancia, k_i);
                    x_resultados = resultados(:, 1);
                    y_resultados = resultados(:, 2);
                    k = boundary(x_resultados, y_resultados);
                    cla(ax_area);
                    fill(ax_area, x_resultados(k), y_resultados(k), [0.9 0.9 0.9], 'EdgeColor', 'none', 'HitTest','off');
                    pltpts = plot(ax_area, x_resultados, y_resultados, '.', 'Color', [0.5 0.5 0.5], 'MarkerSize', 7);
                    plot(ax_area, x_resultados(k), y_resultados(k), 'k-', 'LineWidth', 1.5, 'HitTest','off');
                    xlabel(ax_area, 'k_d'); ylabel(ax_area, '\tau');
                    title(ax_area, 'Área de combinaciones estabilizantes');
                    grid(ax_area, 'on');
                    axis(ax_area, [min(x_resultados)-1 max(x_resultados)+1 min(y_resultados) max(y_resultados)+.03]);
                    pltpts.ButtonDownFcn = @clic_en_punto; 
                catch
                end
                delete(hWait);
            end
        end
    end

    function cambiar_tol()
        resp = inputdlg({'Nuevo valor de tolerancia:'}, 'Modificar tolerancia', [1 35], {num2str(tolerancia)});
        if ~isempty(resp)
            val = str2double(resp{1});
            if isnumeric(val) && val > 0
                hWait = uilabel(panelB,'Position',[170 120 60 40],'FontSize',35,'Text','⏳');
                drawnow;
                try
                    tolerancia = val;
                    btn_tol.Text = sprintf('Modificar tolerancia (%.3f)', tolerancia);
                    resultados = Fun_get_kd_tau_PID_min(a, b, omega_n, zeta, tau_max, omega_max, tolerancia, k_i);
                    x_resultados = resultados(:, 1);
                    y_resultados = resultados(:, 2);
                    k = boundary(x_resultados, y_resultados);
                    cla(ax_area);
                    fill(ax_area, x_resultados(k), y_resultados(k), [0.9 0.9 0.9], 'EdgeColor', 'none', 'HitTest','off');
                    pltpts = plot(ax_area, x_resultados, y_resultados, '.', 'Color', [0.5 0.5 0.5], 'MarkerSize', 7);
                    plot(ax_area, x_resultados(k), y_resultados(k), 'k-', 'LineWidth', 1.5, 'HitTest','off');
                    xlabel(ax_area, 'k_d'); ylabel(ax_area, '\tau');
                    title(ax_area, 'Área de combinaciones estabilizantes');
                    grid(ax_area, 'on');
                    axis(ax_area, [min(x_resultados)-1 max(x_resultados)+1 min(y_resultados) max(y_resultados)+.03]);
                    pltpts.ButtonDownFcn = @clic_en_punto; 
                catch
                end
                delete(hWait);
            end
        end
    end

    function cambiar_ki()
        resp = inputdlg({'Nuevo valor de k_i:'}, 'Modificar k_i', [1 35], {num2str(k_i)});
        if ~isempty(resp)
            val = str2double(resp{1});
            if isnumeric(val) && val > 0
                k_i = val;
                btn_ki.Text = sprintf('Modificar k_i (%.3f)', k_i);
                resultados = Fun_get_kd_tau_PID_min(a, b, omega_n, zeta, tau_max, omega_max, tolerancia, k_i);
                x_resultados = resultados(:, 1);
                y_resultados = resultados(:, 2);
                k = boundary(x_resultados, y_resultados);
                cla(ax_area);
                fill(ax_area, x_resultados(k), y_resultados(k), [0.9 0.9 0.9], 'EdgeColor', 'none', 'HitTest','off');
                pltpts = plot(ax_area, x_resultados, y_resultados, '.', 'Color', [0.5 0.5 0.5], 'MarkerSize', 7);
                plot(ax_area, x_resultados(k), y_resultados(k), 'k-', 'LineWidth', 1.5, 'HitTest','off');
                xlabel(ax_area, 'k_d'); ylabel(ax_area, '\tau');
                title(ax_area, 'Área de combinaciones estabilizantes');
                grid(ax_area, 'on');
                axis(ax_area, [min(x_resultados)-1 max(x_resultados)+1 min(y_resultados) max(y_resultados)+.03]);
                pltpts.ButtonDownFcn = @clic_en_punto; 
            end
        end
    end

    function sintonizar_pid()
        delete(panelD.Children);

        a_val = a;
        b_val = b;
        k_d = selected_params.k_d;
        tau_val = selected_params.tau;
        omega_c1 = selected_params.omega_c1;
        omega_c2 = selected_params.omega_c2;
        ki_val = k_i;

        if isnan(omega_c1) || isnan(omega_c2)
            uilabel(panelD, 'Text', 'Selecciona (k_d, \tau) válidos para calcular el intervalo de k_p.', ...
                'Position', [40 220 670 50], 'FontSize', 15, 'FontColor', [0.8 0.2 0.2]);
            return;
        end

        % f_{Q_4}(\omega)
        prod_min = 1; prod_max = 1;
        for m = 1:N
            prod_min = prod_min * sqrt(omega_c1^4 + 2*omega_n(m)^2*(2*zeta(m)^2 - 1)*omega_c1^2 + omega_n(m)^4);
            prod_max = prod_max * sqrt(omega_c2^4 + 2*omega_n(m)^2*(2*zeta(m)^2 - 1)*omega_c2^2 + omega_n(m)^4);
        end
        fQ4_min = sqrt((omega_c1^2 + a_val^2)*(omega_c1^2 + b_val^2) * prod_min / (1 + (k_d*omega_c1 - ki_val/omega_c1)^2));
        fQ4_max = sqrt((omega_c2^2 + a_val^2)*(omega_c2^2 + b_val^2) * prod_max / (1 + (k_d*omega_c2 - ki_val/omega_c2)^2));
        kp_min = (1/beta) * fQ4_min;
        kp_max = (1/beta) * fQ4_max;
        kp_pidMin = (kp_min + kp_max)/2;

        selected_params.kp_min = kp_min;
        selected_params.kp_max = kp_max;
        selected_params.kp_sel = kp_pidMin;

        anchoIzq = 350; anchoDer = 410; alto = 290; offy = 25;
        panelD_izq = uipanel(panelD, 'Position', [15 offy anchoIzq alto], 'BorderType','none');
        panelD_der = uipanel(panelD, 'Position', [anchoIzq+40 offy anchoDer alto], 'BorderType','none');

        uilabel(panelD_izq, ...
            'Text', sprintf('Intervalo estabilizante de k_p:\n[%.4f , %.4f]', kp_min, kp_max), ...
            'Position', [10 190 330 40], 'FontSize', 15, 'FontWeight', 'bold');
        uilabel(panelD_izq, ...
            'Text', sprintf('Valor sugerido (promedio):\nk_p = %.4f', kp_pidMin), ...
            'Position', [10 145 330 35], 'FontSize', 13);
        uilabel(panelD_izq, ...
            'Text', 'Selecciona un valor de k_p dentro del intervalo:', ...
            'Position', [10 110 250 30], 'FontSize', 13);
        edt_kp = uieditfield(panelD_izq, 'numeric', ...
            'Position', [10 80 90 28], ...
            'Value', kp_pidMin, 'Limits', [kp_min kp_max], 'RoundFractionalValues','off');
        btn_nyq = uibutton(panelD_izq, 'push', 'Text', 'Graficar Nyquist', ...
            'Position', [110 80 180 32], 'FontWeight','bold', 'FontSize',14, ...
            'ButtonPushedFcn', @(src,event) graficar_nyquist());

        ax_nyq = uiaxes(panelD_der, 'Position', [10 5 390 250], 'FontSize',13, 'Box','on');
        title(ax_nyq, 'Diagrama de Nyquist');

        function graficar_nyquist()
            kp_val = edt_kp.Value;
            selected_params.kp_sel = kp_val;
            s = tf('s');
            G_uns = zpk([], [a_val b_val], beta, 'outputdelay', tau_in);
            G_total = G_uns;
            for m = 1:N
                G_par = tf([1], [1 polos_cplx(m,1) polos_cplx(m,2)]);
                G_total = G_total * G_par;
            end
            PID = pid(1, ki_val, k_d);
            Gt = G_total * PID * kp_val;

            w = [0, logspace(-2, 2, 5000)];
            [re, im] = nyquist(Gt, w);
            re = squeeze(re);
            im = squeeze(im);

            cla(ax_nyq);
            plot(ax_nyq, re, im, 'b', 'LineWidth', 1.5); hold(ax_nyq, 'on');
            plot(ax_nyq, re, -im, 'b--', 'LineWidth', 1);
            plot(ax_nyq, -1, 0, 'rx', 'MarkerSize', 10, 'LineWidth', 2);
            xlabel(ax_nyq, 'Re'); ylabel(ax_nyq, 'Im');
            axis(ax_nyq, 'equal');
            grid(ax_nyq, 'on');
            title(ax_nyq, 'Diagrama de Nyquist');
        end
    end
end
