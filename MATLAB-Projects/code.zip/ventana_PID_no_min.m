function ventana_PID_no_min(a, b, tau, polos_cplx, beta)
    % --- PARÁMETROS DEL SISTEMA ---
    N = size(polos_cplx,1);
    omega_n = sqrt(polos_cplx(:,2))';
    zeta = polos_cplx(:,1)' ./ (2*omega_n);
    kd_min = 1/a + 1/b - tau - sum(2*zeta ./ omega_n);
    kd = 2 * kd_min;

    % --- Crear ventana principal ---
    fig = uifigure('Name','PID Fase No Mínima');
    fig.Position = [100 100 1300 720];

    % --- Panel izquierdo: entrada de ki + texto ---
    panel_izq = uipanel(fig, 'Title', 'Parámetros de Control', 'FontSize', 14, ...
        'Position', [20 20 400 680]);

    % Campo para ki
    uilabel(panel_izq, 'Text', 'Valor de k_i:', 'Position', [20 620 100 22]);
    txt_ki = uieditfield(panel_izq, 'numeric', 'Value', 1, ...
        'Position', [130 620 80 22]);

    % Leyenda informativa
uilabel(panel_izq, ...
    'Text', 'Ingrese un valor para k_i y presione "Calcular" para comenzar.', ...
    'Position', [20 595 360 22], ...
    'FontSize', 12, ...
    'FontAngle', 'italic', ...
    'FontColor', [0.3 0.3 0.3]);

    % Botón para calcular
    uibutton(panel_izq, 'Text', 'Calcular', 'FontWeight', 'bold', ...
        'Position', [230 620 100 25], ...
        'ButtonPushedFcn', @(btn,event) calcular());

    % Área de texto para resultados
    txt_out = uitextarea(panel_izq, ...
        'Position', [10 10 380 590], ...
        'FontSize', 13, ...
        'Editable', 'off');

    % Panel derecho superior: fase
    panel_derecho_sup = uipanel(fig, 'Title', '\Phi_{Q_2}(\omega)', 'FontSize', 14, ...
        'Position', [440 380 830 300]);
    ax_fase = uiaxes(panel_derecho_sup, 'Position', [30 30 770 230], 'FontSize', 14);
    xlabel(ax_fase, '\omega'); ylabel(ax_fase, '\Phi_{Q_2}(\omega)');
    grid(ax_fase, 'on');

    % Panel derecho inferior: Nyquist
    panel_derecho_inf = uipanel(fig, 'Title', 'Diagrama de Nyquist', 'FontSize', 14, ...
        'Position', [440 20 830 340]);
    ax_nyq = uiaxes(panel_derecho_inf, 'Position', [30 30 770 270]);
    grid(ax_nyq, 'on');

    % --- Función para cálculo interno ---
    function calcular()
        ki = txt_ki.Value;
        omega = linspace(0.01, 5, 5000);
        phi = zeros(size(omega));
        for i = 1:length(omega)
            w = omega(i);
            suma = atan2(w, a) + atan2(w, b) - w*tau - pi ...
                 - atan2(kd*w - ki/w, 1);
            for m = 1:N
                num = 2 * omega_n(m) * zeta(m) * w;
                den = omega_n(m)^2 - w^2;
                suma = suma - atan2(num, den);
            end
            phi(i) = suma;
        end

        % --- Cruces por -pi ---
        cruces = find(diff(sign(phi + pi)) ~= 0);
        omega_c0 = omega(cruces(1));
        omega_c1 = omega(cruces(2));
        omega_c2 = omega(cruces(3));

        % --- Cortar omega hasta 10% después de omega_c2 ---
        omega_max = 1.1 * omega_c2;
        idx = omega <= omega_max;
        omega_cortado = omega(idx);
        phi_cortado = phi(idx);

        % --- Graficar fase ---
        cla(ax_fase);
        plot(ax_fase, omega_cortado, phi_cortado, 'b', 'LineWidth', 1.5);
        hold(ax_fase, 'on');
        yline(ax_fase, -pi, '--k', 'LineWidth', 1.2);
        hold(ax_fase, 'off');

        % --- f_{Q_2}(omega) ---
        fQ2 = @(w) sqrt( ...
            (w^2 + a^2)*(w^2 + b^2) * ...
            prod(arrayfun(@(wn,z) (w^4 + 2*(2*z^2 - 1)*wn^2*w^2 + wn^4), omega_n, zeta)) / ...
            (1 + (kd*w - ki/w)^2));

        M0 = fQ2(omega_c0);
        M1 = fQ2(omega_c1);
        M2 = fQ2(omega_c2);

        if M2 < M0
            omega_cg = omega_c2;
        else
            omega_cg = omega_c0;
        end

        kp_min = (1/beta) * fQ2(omega_c1);
        kp_max = (1/beta) * fQ2(omega_cg);
        kp = (kp_min + kp_max)/2;

        % --- Mostrar resultados ---
        txt_out.Value = {
            sprintf('k_d mínimo = %.4f', kd_min)
            sprintf('k_d seleccionado = %.4f', kd)
            sprintf('k_i seleccionado = %.4f', ki)
            sprintf('\\omega_{c_0} = %.4f', omega_c0)
            sprintf('\\omega_{c_1} = %.4f', omega_c1)
            sprintf('\\omega_{c_2} = %.4f', omega_c2)
            sprintf('M_{Q_2}(\\omega_{c_0}) = %.4f', M0)
            sprintf('M_{Q_2}(\\omega_{c_2}) = %.4f', M2)
            sprintf('Intervalo de k_p: [%.4f , %.4f]', kp_min, kp_max)
            sprintf('Valor sugerido: k_p = %.4f', kp)
            ''
            'Diagrama de Nyquist con:'
            'PID = pid(-1,k_i,k_d)'
            'Gt = G_s * PID * k_p'
        };

        % --- Diagrama de Nyquist ---
        s = tf('s');
        PID = pid(-1, ki, kd);
        den = (s - a)*(s - b);
        for i = 1:N
            den = den * (s^2 + polos_cplx(i,1)*s + polos_cplx(i,2));
        end
        Gs = (beta * exp(-tau * s)) / den;
        Gt = Gs * PID * kp;

        % Nyquist
        w = logspace(-2, 2, 5000);
        [re, im] = nyquist(Gt, w);
        re = squeeze(re);
        im = squeeze(im);

        cla(ax_nyq);
        plot(ax_nyq, re, im, 'b', 'LineWidth', 1.5); hold(ax_nyq, 'on');
        plot(ax_nyq, re, -im, 'b--', 'LineWidth', 1);
        plot(ax_nyq, -1, 0, 'rx', 'MarkerSize', 10, 'LineWidth', 2);
        xlabel(ax_nyq, 'Re'); ylabel(ax_nyq, 'Im');
        axis(ax_nyq, 'equal');
        grid(ax_nyq, 'on');
        title(ax_nyq, 'Diagrama de Nyquist');
    end
end
