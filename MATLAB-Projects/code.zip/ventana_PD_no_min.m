function ventana_PD_no_min(a, b, tau, polos_cplx, beta)

    % --- PARÁMETROS DEL SISTEMA ---
    N = size(polos_cplx,1);
    omega_n = sqrt(polos_cplx(:,2))';
    zeta = polos_cplx(:,1)' ./ (2*omega_n);

    % --- Cálculo de k_d mínimo y selección de k_d ---
    kd_min = 1/a + 1/b - tau - sum(2*zeta ./ omega_n);
    kd = 2 * kd_min;

    % --- CREAR VENTANA ---
    fig = uifigure('Name','PD Fase No Mínima');
    fig.Position = [100 100 1250 700];

    % --- PANEL IZQUIERDO: Intervalo de kp ---
    panel_izq = uipanel(fig, 'Title', 'Intervalo de k_p', 'FontSize', 14, ...
        'Position', [20 20 400 660]);

    txt_out = uitextarea(panel_izq, ...
        'Position', [10 10 380 600], ...
        'FontSize', 13, ...
        'Editable', 'off');

    % --- PANEL DERECHO SUPERIOR: Diagrama de Fase ---
    panel_derecho_sup = uipanel(fig, 'Title', '\Phi_{Q_1}(\omega)', 'FontSize', 14, ...
        'Position', [440 370 780 310]);
    ax_fase = uiaxes(panel_derecho_sup, 'Position', [30 30 720 240], 'FontSize', 14);
    xlabel(ax_fase, '\omega'); ylabel(ax_fase, '\Phi_{Q_1}(\omega)');
    grid(ax_fase, 'on');

    % --- PANEL DERECHO INFERIOR: Nyquist ---
    panel_derecho_inf = uipanel(fig, 'Title', 'Diagrama de Nyquist', 'FontSize', 14, ...
        'Position', [440 20 780 330]);
    ax_nyq = uiaxes(panel_derecho_inf, 'Position', [30 30 720 270]);
    grid(ax_nyq, 'on');

    % --- Cálculo de Fase con atan2 ---
    omega = linspace(0.01, 5, 5000);
    phi = zeros(size(omega));
    for i = 1:length(omega)
        w = omega(i);
        suma = atan2(w, a) + atan2(w, b) - w*tau - pi - atan2(kd*w, 1);
        for m = 1:N
            num = 2 * omega_n(m) * zeta(m) * w;
            den = omega_n(m)^2 - w^2;
            suma = suma - atan2(num, den);
        end
        phi(i) = suma;
    end

    % --- Detectar cruces por -pi ---
    cruces = find(diff(sign(phi + pi)) ~= 0);
    omega_c0 = 0;
    omega_c1 = omega(cruces(1));
    omega_c2 = omega(cruces(2));

    % --- Recorte para graficar solo hasta omega_c2 ---
    limite = 1.1 * omega_c2;
    indices = omega <= limite;
    omega_cortado = omega(indices);
    phi_cortado = phi(indices);

    % --- Gráfica de fase ---
    plot(ax_fase, omega_cortado, phi_cortado, 'b', 'LineWidth', 1.5);
    hold(ax_fase, 'on');
    yline(ax_fase, -pi, '--k', 'LineWidth', 1.2);
    hold(ax_fase, 'off');

    % --- Función f_{Q_1} ---
    fQ = @(w) sqrt( ...
        (w^2 + a^2)*(w^2 + b^2) * ...
        prod(arrayfun(@(wn,z) (w^4 + 2*wn^2*(2*z^2 - 1)*w^2 + wn^4), omega_n, zeta)) / ...
        (1 + (kd^2)*w^2));

    M0 = fQ(omega_c0);
    M1 = fQ(omega_c1);
    M2 = fQ(omega_c2);

    if M2 < M0
        omega_cg = omega_c2;
    else
        omega_cg = omega_c0;
    end

    % --- Intervalo de kp ---
    kp_min = (1/beta) * fQ(omega_c1);
    kp_max = (1/beta) * fQ(omega_cg);
    kp = (kp_min + kp_max) / 2;

    % --- Mostrar información ---
    txt_out.Value = {
        sprintf('k_d mínimo = %.4f', kd_min)
        sprintf('k_d seleccionado = %.4f', kd)
        sprintf('\\omega_{c_1} = %.4f', omega_c1)
        sprintf('\\omega_{c_2} = %.4f', omega_c2)
        sprintf('M_{Q_1}(\\omega_{c_0}) = %.4f', M0)
        sprintf('M_{Q_1}(\\omega_{c_2}) = %.4f', M2)
        sprintf('Intervalo de k_p: [%.4f , %.4f]', kp_min, kp_max)
        sprintf('Valor sugerido: k_p = %.4f', kp)
        ''
        'Diagrama de Nyquist con:'
        'PD = pid(-1,0,k_d)'
        'Gt = G_s * PD * k_p'
    };

    % --- Diagrama de Nyquist ---
    s = tf('s');
    PD = pid(-1, 0, kd);
    den = (s - a)*(s - b);
    for i = 1:N
        den = den * (s^2 + polos_cplx(i,1)*s + polos_cplx(i,2));
    end
    Gs = (beta * exp(-tau * s)) / den;
    Gt = Gs * PD * kp;

    % Nyquist con mayor resolución
    w = [0, logspace(-2, 2, 5000)];
    [re, im] = nyquist(Gt, w);
    re = squeeze(re);
    im = squeeze(im);

    cla(ax_nyq);
    plot(ax_nyq, re, im, 'b', 'LineWidth', 1.5); hold(ax_nyq, 'on');
    plot(ax_nyq, re, -im, 'b--', 'LineWidth', 1);
    plot(ax_nyq, -1, 0, 'rx', 'MarkerSize', 10, 'LineWidth', 2);
    xlabel(ax_nyq, 'Re'); ylabel(ax_nyq, 'Im');
    axis(ax_nyq, 'equal');
    grid(ax_nyq, 'on');
    title(ax_nyq, 'Diagrama de Nyquist');

end
